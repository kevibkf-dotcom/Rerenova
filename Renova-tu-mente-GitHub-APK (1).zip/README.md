# Renova tu mente

App Android offline de apoyo para disciplina personal, lectura bíblica, reflexión, progreso y motivación para entrenar.

## Incluye
- Biblioteca bíblica con pasajes completos seleccionados (Reina-Valera 1909, dominio público).
- Búsqueda por referencia, texto, categoría y tema.
- Secciones Jesús, Dios, Mente, Disciplina y tentación.
- Calendario mensual y racha local.
- Pantalla de ayuda para momentos de tentación.
- Motivaciones originales.
- Modo disciplina/Gym.
- Sin servidor ni cuenta obligatoria.
- GitHub Actions para compilar la APK.

## Crear APK en GitHub
1. Sube el proyecto a un repositorio.
2. Ve a **Actions**.
3. Abre **Build APK - Renova tu mente**.
4. Pulsa **Run workflow**.
5. Al terminar, descarga el artefacto `renova-tu-mente-debug-apk`.

## Desarrollo local
Requiere JDK 17 y Android SDK 35. El workflow genera el Gradle Wrapper automáticamente si el repositorio no lo tiene.
