package com.renovatumente.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.text.*;
import java.util.*;

public class MainActivity extends Activity {
    AppView v;
    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(11,16,32));
        getWindow().setNavigationBarColor(Color.rgb(11,16,32));
        v=new AppView(this); setContentView(v);
    }
    static class Item { String ref,text,cat,topic; Item(String r,String t,String c,String p){ref=r;text=t;cat=c;topic=p;} }

    class AppView extends View {
        Paint p=new Paint(3); ArrayList<Item> verses=new ArrayList<>();
        ArrayList<String[]> mot=new ArrayList<>(), gym=new ArrayList<>();
        int page=0; String search=""; int selectedTab=0; Random rnd=new Random();
        SharedPreferences prefs;
        int purple=Color.rgb(124,92,252), bg=Color.rgb(11,16,32), card=Color.rgb(23,29,48), text=Color.rgb(241,244,250), muted=Color.rgb(160,169,190);
        AppView(Context c){super(c); prefs=getSharedPreferences("progress",0); load(); p.setTypeface(Typeface.create("sans",0)); setFocusable(true);}
        void load(){ try{
            String s=new String(getAssets().open("content.json").readAllBytes(),"UTF-8"); JSONObject o=new JSONObject(s);
            JSONArray a=o.getJSONArray("verses"); for(int i=0;i<a.length();i++){JSONObject x=a.getJSONObject(i);verses.add(new Item(x.getString("ref"),x.getString("text"),x.getString("category"),x.getString("topic")));}
            JSONArray m=o.getJSONArray("motivations"); for(int i=0;i<m.length();i++){JSONObject x=m.getJSONObject(i);mot.add(new String[]{x.getString("title"),x.getString("text")});}
            JSONArray g=o.getJSONArray("gym"); for(int i=0;i<g.length();i++){JSONObject x=g.getJSONObject(i);gym.add(new String[]{x.getString("title"),x.getString("text")});}
        }catch(Exception e){}}
        void txt(Canvas c,String s,float x,float y,float size,int color){p.setColor(color);p.setTextSize(size);p.setTypeface(Typeface.create("sans",Typeface.NORMAL));c.drawText(s,x,y,p);}
        void bold(Canvas c,String s,float x,float y,float size,int color){p.setColor(color);p.setTextSize(size);p.setTypeface(Typeface.create("sans",Typeface.BOLD));c.drawText(s,x,y,p);}
        void round(Canvas c,float l,float t,float r,float b,float rad,int color){p.setColor(color);c.drawRoundRect(l,t,r,b,rad,rad,p);}
        @Override protected void onDraw(Canvas c){super.onDraw(c);c.drawColor(bg); if(page==0)home(c);else if(page==1)bible(c);else if(page==2)progress(c);else if(page==3)gym(c);else emergency(c); nav(c);}
        void header(Canvas c,String title,String sub){bold(c,title,24,48,26,text);txt(c,sub,24,74,13,muted);}
        void home(Canvas c){
            header(c,"Renova tu mente","Fe • disciplina • progreso");
            int streak=prefs.getInt("streak",0), days=prefs.getInt("days",0);
            round(c,20,94,getWidth()-20,220,24,card);
            txt(c,"🔥  RACHA ACTUAL",38,126,12,muted); bold(c,""+streak,38,174,48,text);txt(c,"días",102,173,18,muted);
            txt(c,"Días registrados: "+days,38,202,13,muted);
            round(c,20,238,getWidth()-20,410,24,Color.rgb(34,27,61));
            bold(c,"✝  VERSÍCULO PARA HOY",38,270,12,Color.rgb(192,180,255));
            Item it=verses.get(Calendar.getInstance().get(Calendar.DAY_OF_YEAR)%verses.size());
            bold(c,it.ref,38,302,17,text); wrap(c,it.text,38,328,getWidth()-55,15,text);
            round(c,20,428,(getWidth()-30)/2,520,20,card); bold(c,"🚨",38,462,24,text);bold(c,"TENTACIÓN",38,488,14,text);txt(c,"Necesito ayuda",38,507,11,muted);
            round(c,(getWidth()+10)/2,428,getWidth()-20,520,20,card);bold(c,"🏋",38+(getWidth()/2),462,22,text);bold(c,"DISCIPLINA",38+(getWidth()/2),488,14,text);txt(c,"Entrenar hoy",38+(getWidth()/2),507,11,muted);
            round(c,20,538,getWidth()-20,612,18,purple);bold(c,"✦  MOTIVACIÓN DEL DÍA",38,566,12,Color.WHITE);wrap(c,mot.get(Calendar.getInstance().get(Calendar.DAY_OF_YEAR)%mot.size())[1],38,590,getWidth()-55,13,Color.WHITE);
        }
        void bible(Canvas c){
            header(c,"Biblioteca bíblica","Busca por Jesús, Dios, tentación, pureza, fuerza...");
            round(c,20,92,getWidth()-20,140,16,card);txt(c,"🔎  "+(search.length()==0?"Buscar en la Biblia":search),38,122,14,text);
            String[] cats={"Todos","Jesús","Dios","Mente","Disciplina"};
            int x=20; for(String q:cats){round(c,x,154,x+82,190,14,q.equals(search)?purple:card);txt(c,q,x+10,178,11,text);x+=90;}
            int y=214,n=0;
            for(Item it:verses){ if(search.length()>0 && !it.ref.toLowerCase().contains(search.toLowerCase()) && !it.text.toLowerCase().contains(search.toLowerCase()) && !it.cat.toLowerCase().contains(search.toLowerCase()) && !it.topic.toLowerCase().contains(search.toLowerCase()))continue;
                round(c,20,y,getWidth()-20,y+148,20,card);txt(c,it.cat.toUpperCase()+" • "+it.topic,36,y+25,10,Color.rgb(175,160,255));bold(c,it.ref,36,y+51,16,text);wrap(c,it.text,36,y+76,getWidth()-45,13,text);y+=162;if(++n>=4)break;}
            if(n==0)txt(c,"No encontramos resultados. Prueba otra palabra.",28,235,14,muted);
        }
        void progress(Canvas c){
            header(c,"Mi progreso","Un registro sencillo para avanzar día a día");
            int streak=prefs.getInt("streak",0), days=prefs.getInt("days",0);
            round(c,20,96,getWidth()-20,188,22,card);bold(c,"🔥 "+streak+" días",38,132,24,text);txt(c,"racha actual",38,158,12,muted);
            round(c,20,206,(getWidth()-30)/2,286,18,card);bold(c,""+days,38,240,25,text);txt(c,"días logrados",38,263,11,muted);
            round(c,(getWidth()+10)/2,206,getWidth()-20,286,18,card);bold(c,"🏆 "+(streak>=30?"30+":streak>=14?"14+":streak>=7?"7":"1"),38+getWidth()/2,240,25,text);txt(c,"mejor etapa",38+getWidth()/2,263,11,muted);
            bold(c,"CALENDARIO",20,326,13,muted);
            drawCalendar(c,20,346);
            round(c,20,580,getWidth()-20,638,16,purple);bold(c,"✓  MARCAR HOY COMO CONSEGUIDO",38,616,12,Color.WHITE);
        }
        void drawCalendar(Canvas c,int ox,int oy){
            Calendar cal=Calendar.getInstance();int month=cal.get(Calendar.MONTH),year=cal.get(Calendar.YEAR),today=cal.get(Calendar.DAY_OF_MONTH);
            String title=new SimpleDateFormat("MMMM yyyy",Locale.getDefault()).format(cal.getTime());
            bold(c,title.substring(0,1).toUpperCase()+title.substring(1),28,oy+22,16,text);
            String[] w={"L","M","X","J","V","S","D"};for(int i=0;i<7;i++)txt(c,w[i],30+i*48,oy+48,10,muted);
            Calendar first=(Calendar)cal.clone();first.set(Calendar.DAY_OF_MONTH,1);int start=first.get(Calendar.DAY_OF_WEEK)-2;if(start<0)start=6;
            int max=cal.getActualMaximum(Calendar.DAY_OF_MONTH);
            for(int d=1;d<=max;d++){int k=start+d-1,row=k/7,col=k%7;float x=20+col*48,y=oy+58+row*38;boolean ok=prefs.getBoolean("d"+year+"_"+month+"_"+d,false);round(c,x,y,x+30,y+30,10,ok?purple:card);txt(c,""+d,x+10,y+20,10,text);}
        }
        void gym(Canvas c){
            header(c,"Disciplina","Entrena el cuerpo. Entrena también la decisión.");
            round(c,20,96,getWidth()-20,184,22,card);bold(c,"🏋  HOY",38,130,12,muted);bold(c,gym.get(Calendar.getInstance().get(Calendar.DAY_OF_YEAR)%gym.size())[0],38,158,21,text);
            int y=204; for(String[] g:gym){round(c,20,y,getWidth()-20,y+92,18,card);bold(c,g[0],36,y+30,13,text);wrap(c,g[1],36,y+53,getWidth()-45,12,muted);y+=104;}
        }
        void emergency(Canvas c){
            header(c,"Estoy teniendo una tentación","Pausa. Respira. Cambia de ambiente.");
            round(c,20,98,getWidth()-20,246,24,Color.rgb(47,25,45));bold(c,"🚨  NO DECIDAS EN CALIENTE",38,135,15,text);wrap(c,"Una urgencia no es una orden. Date unos minutos antes de hacer cualquier cosa.",38,166,getWidth()-50,15,text);
            round(c,20,268,getWidth()-20,324,17,purple);bold(c,"📖  LEER UN PASAJE",38,302,13,Color.WHITE);
            Item it=verses.get((int)(System.currentTimeMillis()/60000)%verses.size());
            round(c,20,342,getWidth()-20,500,20,card);bold(c,it.ref,36,375,17,text);wrap(c,it.text,36,402,getWidth()-45,14,text);
            bold(c,"AHORA HAZ ESTO",20,540,13,muted);
            txt(c,"1. Levántate y cambia de lugar.",28,568,13,text);txt(c,"2. Respira lento durante un minuto.",28,592,13,text);txt(c,"3. Camina, entrena o habla con alguien.",28,616,13,text);
        }
        void wrap(Canvas c,String s,float x,float y,float right,float size,int color){
            p.setTextSize(size);p.setTypeface(Typeface.create("sans",0));float max=right-x;String[] words=s.split(" ");String line="";
            for(String w:words){String test=line.length()==0?w:line+" "+w;if(p.measureText(test)>max){txt(c,line,x,y,size,color);y+=size+5;line=w;}else line=test;}if(line.length()>0)txt(c,line,x,y,size,color);
        }
        void nav(Canvas c){
            int h=getHeight();round(c,0,h-78,getWidth(),h,0,Color.rgb(14,19,35));
            String[] ns={"⌂","▤","🔥","⚡","🚨"};String[] ls={"Inicio","Biblia","Progreso","Gym","Ayuda"};
            for(int i=0;i<5;i++){float x=30+i*(getWidth()-60)/4f;int col=(page==i?purple:muted);txt(c,ns[i],x,h-48,20,col);txt(c,ls[i],x-12,h-22,9,col);}
        }
        @Override public boolean onTouchEvent(android.view.MotionEvent e){
            if(e.getAction()!=MotionEvent.ACTION_UP)return true;float x=e.getX(),y=e.getY();int h=getHeight();
            if(y>h-90){if(x<getWidth()/5)page=0;else if(x<2*getWidth()/5)page=1;else if(x<3*getWidth()/5)page=2;else if(x<4*getWidth()/5)page=3;else page=4;invalidate();return true;}
            if(page==0 && y>420&&y<530){if(x<getWidth()/2)page=4;else page=3;invalidate();return true;}
            if(page==2 && y>560&&y<650){Calendar cal=Calendar.getInstance();String k="d"+cal.get(Calendar.YEAR)+"_"+cal.get(Calendar.MONTH)+"_"+cal.get(Calendar.DAY_OF_MONTH);boolean now=!prefs.getBoolean(k,false);prefs.edit().putBoolean(k,now).putInt("days",Math.max(0,prefs.getInt("days",0)+(now?1:-1))).putInt("streak",now?prefs.getInt("streak",0)+1:0).apply();invalidate();return true;}
            if(page==1 && y>90&&y<145){ final EditText in=new EditText(MainActivity.this);in.setSingleLine();in.setHint("Ej.: Jesús, tentación, fuerza");new AlertDialog.Builder(MainActivity.this).setTitle("Buscar en la Biblia").setView(in).setPositiveButton("Buscar",(d,w)->{search=in.getText().toString();invalidate();}).setNegativeButton("Cancelar",null).show();return true;}
            if(page==1 && y>145&&y<200){int idx=(int)((x-20)/90);String[] cats={"Todos","Jesús","Dios","Mente","Disciplina"};if(idx>=0&&idx<cats.length)search=cats[idx].equals("Todos")?"":cats[idx];invalidate();}
            return true;
        }
    }
}
